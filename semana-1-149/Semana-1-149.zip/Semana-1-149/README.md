# semana-1-149

Colaboradores

Jesús David Rivas Losada
GitHub user: ijesusrivas93
Email: rivas.jesus93@gmail.com

Juan Francisco Pabón Caviativa
Github user: juanfpc
Email: juanfpc@hotmail.com

Santiago Monsalve Botero
Github user: smonsal
Email: samonsalvebo@gmail.com

Por medio de este primero reto, se busca la primera interacción con el desarrollo de software a través de HTML
El grupo 149 del Ciclo 3 de Mision TIC 2022, desarrolló una interfaz dónde se cumplían con las siguientes especificaciones

1. Un encabezado, el cual contuviera un hipervinculo con cada una de las partes de este trabajo
2. Una imagen de bienvenida
3. Un recuadro, el cual se encuentra dividido en 3 partes, para poner los 3 servicios que propusimos para el desarrollo
4. Un recuadro, el cual se encuentra dividido en 4 partes, para colocar 4 noticias con los vínculos directos a las noticias y una imagen referencial para cada noticia
5. Un recuadro, el cual se encuentra dividido en 3 partes, para colocar información de cada uno de los colaborades, tales como: Nombre Completo, Hobbies, Profesión, Edad
6. Un recuadro, el cual se encuentra dividido en 2 partes, con el fin de colocar un píe de página o "footer", el cual contiene información de contacto, link directo al repositorio del equipo 149 en GitHub

Para el desarrollo de este software, Juan Pabón desarrollo la parte inicial del proyecto, con sus respectivos recuadros tanto de texto como de imagen, Jesús Rivas realizó toda la parte de organizar la arquitectura del desarrollo y correcciones finales, Santiago Monsalve se encargó de la parte de la información, los colores y las imágenes del desarrollo.

Primera versión
